package com.codingdojo.driverslicense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriversLicenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriversLicenseApplication.class, args);
	}

}
