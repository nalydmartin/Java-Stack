package com.codingdojo.beltreview2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Beltreview2Application {

	public static void main(String[] args) {
		SpringApplication.run(Beltreview2Application.class, args);
	}

}
