package com.codingdojo.beltreview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeltReviewApplicationTests {

	@Test
	void contextLoads() {
	}

}
