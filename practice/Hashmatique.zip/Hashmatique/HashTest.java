

public class HashTest {
    public static void main(String[] args) {
        Hash.hashMap();
    }
}
