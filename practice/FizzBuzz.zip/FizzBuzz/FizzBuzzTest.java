public class FizzBuzzTest {
    public static void main(String[] args) {

        int number = 9;
        FizzBuzz cow = new FizzBuzz();
        String word = cow.fizzBuzz(number);
        System.out.println(word);
    }
}