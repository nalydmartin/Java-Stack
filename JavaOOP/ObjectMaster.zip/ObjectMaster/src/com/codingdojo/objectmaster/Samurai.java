package com.codingdojo.objectmaster;

public class Samurai {

}
