package com.codingdojo.objectmaster;

public class Wizard {

}
