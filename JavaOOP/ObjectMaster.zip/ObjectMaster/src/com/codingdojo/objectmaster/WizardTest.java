package com.codingdojo.objectmaster;

public class WizardTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
