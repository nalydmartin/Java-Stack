package com.codingdojo.objectmaster;

public class Ninja {

}
