package com.codingdojo.zookeeper;

public class ZooKeeper {
	private int energyLevel = 100;
	
	public Integer displayEnergy() {
		System.out.println(energyLevel);
		return energyLevel;
	}
	
	
	
}
